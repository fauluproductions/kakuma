// --- toggle menu ---//

var navLinks = document.getElementById("navLinks");
function showMenu(){
    navLinks.style.right = "0";
};
var navLinks = document.getElementById("navLinks");
function hideMenu(){
    navLinks.style.right = "-200px";
};


//send emial//
function sendEmail(){
    Email.send({
        Host : "smtp.gmail.com",
        Username : "thon2019.kuany@gmail.com",
        Password : "password",
        To : 'thonkuanygiet100@gmail.com',
        From : document.getElementById("email").value,
        Subject : "New Contact Enquiry",
        Body : "Sent Successfully"
    }).then(
      message => alert(message)
    );
}